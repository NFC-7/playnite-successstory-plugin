﻿using System;

namespace CommonPluginsControls.LiveChartsCommon
{
    public class CustomerForSingle
    {
        public string Icon { get; set; }
        public string IconText { get; set; }

        public string Name { get; set; }
        public double Values { get; set; }
    }
}
