[![Crowdin](https://badges.crowdin.net/playnite-extensions/localized.svg)](https://crowdin.com/project/playnite-extensions)
[![GitHub commit activity](https://img.shields.io/github/commit-activity/m/Lacro59/playnite-plugincommon)](https://github.com/Lacro59/playnite-plugincommon/graphs/commit-activity)
[![GitHub contributors](https://img.shields.io/github/contributors/Lacro59/playnite-plugincommon?cacheSeconds=5000)](https://github.com/Lacro59/playnite-plugincommon/graphs/contributors)
[![GitHub](https://img.shields.io/github/license/Lacro59/playnite-plugincommon?cacheSeconds=50000)](https://github.com/Lacro59/playnite-plugincommon/blob/master/LICENSE)

# playnite-plugincommon
Common files and functions at plugins for [Playnite](https://playnite.link).

## More
Remember to support [Playnite](https://www.patreon.com/playnite) and [Freepik](https://www.flaticon.com/authors/freepik).
