﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonPluginsShared.Interfaces
{
    public interface IDataContext
    {
        bool IsActivated { get; set; }
    }
}
