﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonPlayniteShared.PluginLibrary.HumbleLibrary.Models
{
    public class UserHome
    {
        public List<string> gamekeys;
    }
}
