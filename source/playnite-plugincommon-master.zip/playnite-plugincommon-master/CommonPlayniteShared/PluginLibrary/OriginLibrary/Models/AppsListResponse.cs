﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonPlayniteShared.PluginLibrary.OriginLibrary.Models
{
    public class AppsListResponse
    {
        public int totalCount;
        public List<GameStoreDataResponse> offers;
    }
}
