﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonPlayniteShared.PluginLibrary.EpicLibrary.Models
{
    public class PlaytimeItem
    {
        public string accountId;
        public string artifactId;
        public int totalTime;
    }
}