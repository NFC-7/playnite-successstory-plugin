﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonPlayniteShared.Native
{
    public class Fileapi
    {
        public const uint FILE_FLAG_BACKUP_SEMANTICS = 0x2000000;
    }
}
