﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonPluginsStores.Gog.Models
{
    public class PriceData
    {
        public dynamic DataObj { get; set; }
        public string CodeCurrency { get; set; }
        public string SymbolCurrency { get; set; }
    }
}
