﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonPluginsStores.Steam.Models.SteamKit
{
    public class SteamApp
    {
        public uint AppId { get; set; }
        public string Name { get; set; }
    }
}
