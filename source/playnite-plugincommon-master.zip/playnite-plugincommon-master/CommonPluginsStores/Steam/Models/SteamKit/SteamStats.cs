﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonPluginsStores.Steam.Models.SteamKit
{
    public class SteamStats
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
}
