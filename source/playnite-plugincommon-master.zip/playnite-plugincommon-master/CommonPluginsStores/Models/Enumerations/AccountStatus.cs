﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CommonPluginsStores.Models.Enumerations
{
    public enum AccountStatus
    {
        Checking,
        Private,
        Public
    }
}
