﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CommonPluginsStores.Origin.Models
{
    public class Encoded
    {
        public string id { get; set; }
    }
}
